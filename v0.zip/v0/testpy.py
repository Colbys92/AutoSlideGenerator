from lxml import etree
from io import StringIO
from pptx import Presentation
from pptx.util import Inches

# import the xml file
xml='<user><diapo><title data-id="1">Test presentation</title></diapo><diapo><title data-id="2">Hello world</title> <subtitle>departement project</subtitle> </diapo><diapo><title data-id="3"> with normal text </title> <paragraph>my paragraph with one message </paragraph> </diapo> <diapo> <title data-id="4"> with bullet points </title> <bullet data-id="1"> first bullet point </bullet> <bullet data-id="1"> second bullet point </bullet> <bullet data-id="2"> third bullet point </bullet> </diapo> <diapo> <title data-id=« 5 »>with text and image</title><paragraph>jolie image</paragraph><image><img src=« img.jpg »/></image></diapo></user>'
tree = etree.parse(StringIO(xml))
# tree = etree.parse("data.xml")

# import the diapositive masque
prs = Presentation('masque2.pptx')

# tranform it in tree
diap=tree.getroot().xpath('diapo')

# define layout
title_slide_layout = prs.slide_layouts[2]
title2_slide_layout = prs.slide_layouts[0]
bullet_slide_layout = prs.slide_layouts[1]
only_title_slide_layout = prs.slide_layouts[5]
title_bullet_image_layout = prs.slide_layouts[8]

# import images
images = tree.xpath('//img/@src')
print(images)

for i in range(len(tree.xpath("/user/diapo"))):
    ## access to all titles successively
    titre=((diap[i]).xpath('title'))[0]

    # title only atribute
    if titre.get("data-id")=="1":
        print(title0.text)
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        title.text = titre.text

    # title and subtitule attribute
    elif titre.get("data-id")=="2":
        print(titre.text)
        sub=(diap[i]).xpath('subtitle')
        print(sub[0].text)
        slide = prs.slides.add_slide(title2_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        title.text = titre.text
        subtitle.text = sub[0].text

    # title and a small text paragraph
    elif titre.get("data-id")=="3":
        print(titre.text)
        par=(diap[i]).xpath('paragraph')
        slide = prs.slides.add_slide(only_title_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        title_shape.text = titre.text
        left = Inches(2)
        top = Inches(3)
        width = height = Inches(8)
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        print(par[0].text)
        tf.text = par[0].text

    # title and bullet point
    elif titre.get("data-id")=="4":
        print(titre.text)
        bul=(diap[i]).xpath('bullet')
        slide = prs.slides.add_slide(bullet_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        body_shape = shapes.placeholders[1]
        title_shape.text = titre.text
        tf = body_shape.text_frame
        tf.text = bul[0].text
        for k in range(1,len(bul)):
            print(bul[k].text)
            p = tf.add_paragraph()
            p.text = bul[k].text
            p.level = int(bul[k].get("data-id"))

    # title and bullet and one image
    elif titre.get("data-id") == "5":
        print(titre.text)
        par = (diap[i]).xpath('paragraph')
        slide = prs.slides.add_slide(only_title_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        title_shape.text = titre.text
        left = Inches(1)
        top = Inches(3)
        width = Inches(4)
        height = Inches(6)
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        print(par[0].text)
        tf.text = par[0].text

        left = Inches(6)
        top = Inches(3)
        height=Inches(2.5)
        myimage = (diap[i]).xpath('image')[0]
        pic=slide.shapes.add_picture(myimage,left,top,height=height)


prs.save('testmod.pptx')

